import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Random; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Flocking extends PApplet {


Random rand = new Random();

public ArrayList<Bird> birds = new ArrayList<Bird>();
public ArrayList<Predator> predators = new ArrayList<Predator>();
public float[] parameters = new float[11];

public void setup(){
	
	noStroke();
	frameRate(30);
	fill(0);
	
	for(int i = 0; i < 200; i++){
		birds.add(createRandomBird());
	}
	updateParameters();
}

public void draw(){
	background(255);
	for(Bird b : birds){
		b.updateVelocity();
		b.updatePosition();
		b.drawBird();
	}
	for(Predator p : predators){
		p.updateVelocity();
		p.updatePosition();
		p.drawBird();
	}
}

public Bird createRandomBird(){
	int x = rand.nextInt(width);
	int y = rand.nextInt(height);
	float v_x = (float)rand.nextGaussian()*2;
	float v_y = (float)rand.nextGaussian()*2;
	PVector v = new PVector(v_x, v_y);
	Bird b = new Bird(x, y, v);
	return b;
}

<T extends Bird> PVector getClosestBird(Bird thisBird, ArrayList<T> list){
	PVector closestDisplacement = new PVector(width, height);
	for(Bird b : list){
		PVector displacement = PVector.sub(b.position, thisBird.position);
		if(displacement.x > width/2){
			displacement.x -= width;
		}
		if(displacement.x < -width/2){
			displacement.x += width;
		}
		if(displacement.y > height/2){
			displacement.y -= height;
		}
		if(displacement.y < -height/2){
			displacement.y += height;
		}
		if(displacement.mag() < closestDisplacement.mag() && displacement.mag() > 0){
			closestDisplacement = displacement;
		}
	}
	return closestDisplacement;
}

public ArrayList<Bird> getNeighbors(Bird thisBird, float radius, float angle){
	ArrayList<Bird> toReturn = new ArrayList<Bird>();
	for(Bird b : birds){
		PVector displacement = PVector.sub(b.position, thisBird.position);
		if(displacement.x > width/2){
			displacement.x -= width;
		}
		if(displacement.y > height/2){
			displacement.y -= height;
		}
		if(displacement.mag() < radius && displacement.mag() > 0){
			if(Math.abs(displacement.heading() - thisBird.velocity.heading()) < angle/2){
				toReturn.add(b);
			}
		}
	}
	return toReturn;
}

public void mouseClicked(){
	if(mouseButton == LEFT){
		predators.add(new Predator(createRandomBird()));
	}else if(mouseButton == RIGHT){
		if(predators.size() > 0){
			predators.remove(predators.size() - 1);
		}
	}else if(mouseButton == CENTER){
		updateParameters();
	}
}

public void updateParameters(){
	BufferedReader input = createReader("Flocking Parameters.txt");
	
	try{
		for(int i = 0; i < parameters.length; i++){
			String data = input.readLine();
			int colonIndex = data.indexOf(':');
			data = data.substring(colonIndex + 1, data.length()).trim();
			parameters[i] = Float.parseFloat(data);
		}

	}
	catch(IOException e){
		e.printStackTrace();
	}
	catch(RuntimeException e){
		e.printStackTrace();
	}
	finally{
		try{
			input.close();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		catch(RuntimeException e){
			e.printStackTrace();
		}
	}
}
class Bird{
	PVector position;
	PVector velocity;
	
	Bird(){
		position = new PVector(0, 0);
		velocity = new PVector(0, 0);
	}
	
	Bird(int x_, int y_, PVector velocity_){
		position = new PVector(x_, y_);
		velocity = velocity_;
	}
	
	public void updatePosition(){
		position.add(velocity);
		position.x = position.x % width;
		if(position.x < 0){
			position.x += width;
		}
		position.y = position.y % height;
		if(position.y < 0){
			position.y += height;
		}
	}
	
	public void drawBird(){
		translate(position.x, height - position.y);
		rotate(-velocity.heading()-PI/2);
		triangle(0, 8, -3, -1, 3, -1);
		rotate(velocity.heading()+PI/2);
		translate(-position.x, -height + position.y);
	}
	
	public void updateVelocity(){
		//avoid collision
		PVector closestDisplacement = getClosestBird(this, birds);
		PVector velocityChangeFromCollisionAviodance = closestDisplacement.setMag(1/closestDisplacement.mag());
		velocityChangeFromCollisionAviodance.mult(-1);
		
		//steer towards same heading as neighbors
		ArrayList<Bird> neighbors = getNeighbors(this, parameters[6], parameters[5]);
		PVector averageHeading = new PVector();
		for(Bird b : neighbors){
			averageHeading.add(b.velocity);
		}
		if(neighbors.size() > 0){
			averageHeading.div(neighbors.size());
		}
		float directionChangeFromHeadingMatching = averageHeading.heading() - velocity.heading();
		if(directionChangeFromHeadingMatching > PI){
			directionChangeFromHeadingMatching = TWO_PI - directionChangeFromHeadingMatching;
		}
		if(neighbors.size() == 0){
			directionChangeFromHeadingMatching = 0;
		}
		float magnitudeChangeFromHeadingMatching = averageHeading.mag() - velocity.mag();
		
		//steer towards average position of neighbors
		neighbors = getNeighbors(this, parameters[6], parameters[5]);
		PVector averageDisplacement = new PVector();
		for(Bird b : neighbors){
			PVector displacement = PVector.sub(b.position, position);
			if(displacement.x > width/2){
				displacement.x -= width;
			}
			if(displacement.y > height/2){
				displacement.y -= height;
			}
			averageDisplacement.add(displacement);
		}
		if(neighbors.size() > 0){
			averageDisplacement.div(neighbors.size());
		}else{
			averageDisplacement = new PVector(0, 0);			
		}
		
		//predator avoidance
		if(predators.size() > 0){
			PVector predatorDisplacement = getClosestBird(this, predators);
			PVector velocityChangeFromPredatorAviodance = predatorDisplacement.setMag(1/predatorDisplacement.mag());
			velocityChangeFromPredatorAviodance.mult(-1);
			velocity.add(velocityChangeFromPredatorAviodance.mult(parameters[0]));
		}
		
		velocity.add(velocityChangeFromCollisionAviodance.mult(parameters[1]));
		velocity.rotate(directionChangeFromHeadingMatching*parameters[2]);
		velocity.setMag(velocity.mag() + magnitudeChangeFromHeadingMatching*parameters[3]);
		velocity.add(averageDisplacement.mult(parameters[4]/parameters[6]));

		
		if(velocity.mag() > 5){
			velocity.setMag(velocity.mag() - (velocity.mag() - 5)*0.2f);
		}
		if(velocity.mag() < 3){
			velocity.setMag(velocity.mag() + (3 - velocity.mag())*0.4f);
		}
	}
}
class Predator extends Bird{
	Predator(){
		position = new PVector(0, 0);
		velocity = new PVector(0, 0);
	}
	
	Predator(int x_, int y_, PVector velocity_){
		position = new PVector(x_, y_);
		velocity = velocity_;
	}
	
	Predator(Bird b){
		position = b.position;
		velocity = b.velocity;
	}
	
	public void drawBird(){
		translate(position.x, height - position.y);
		rotate(-velocity.heading()-PI/2);
		fill(200, 0, 0);
		triangle(0, 10, -4, -2, 4, -2);
		fill(0);
		rotate(velocity.heading()+PI/2);
		translate(-position.x, -height + position.y);
	}
	
	public void updateVelocity(){
		if(predators.size() > 1){
			PVector closestDisplacement = getClosestBird(this, predators);
			PVector velocityChangeFromCollisionAviodance = closestDisplacement.setMag(1/closestDisplacement.mag());
			velocityChangeFromCollisionAviodance.mult(-1);
			velocity.add(closestDisplacement.mult(parameters[8]));
		}
		
		ArrayList<Bird> neighbors = getNeighbors(this, parameters[10], parameters[9]);
		PVector averageDisplacement = new PVector();
		for(Bird b : neighbors){
			PVector displacement = PVector.sub(b.position, position);
			if(displacement.x > width/2){
				displacement.x -= width;
			}
			if(displacement.y > height/2){
				displacement.y -= height;
			}
			averageDisplacement.add(displacement);
		}
		if(neighbors.size() > 0){
			averageDisplacement.div(neighbors.size());
		}else{
			averageDisplacement = new PVector(0, 0);			
		}
		
		velocity.add(averageDisplacement.mult(parameters[7]/parameters[10]));
				
		if(velocity.mag() > 5){
			velocity.setMag(velocity.mag() - (velocity.mag() - 5)*0.2f);
		}
		if(velocity.mag() < 3){
			velocity.setMag(velocity.mag() + (3 - velocity.mag())*0.4f);
		}
	}
}
  public void settings() { 	size(700, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Flocking" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
